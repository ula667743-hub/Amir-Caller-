AMIR CALLER — মোবাইল দিয়ে APK বানানোর সহজ প্রজেক্ট

এটি ওয়েবসাইট হিসেবে প্রকাশ করার জন্য নয়; Android APK বানানোর সোর্স প্রজেক্ট।
এই ZIP-এ APK ফাইল আগে থেকে নেই। GitHub Actions দিয়ে বিনামূল্যে debug APK build করা যাবে।

মোবাইল থেকে APK বানানোর ধাপ:
1) ফোনের Chrome-এ github.com খুলে বিনামূল্যে account তৈরি/লগইন করুন।
2) New repository তৈরি করুন; নাম দিন AmirCaller এবং Public নির্বাচন করুন।
3) ZIP ফাইলটি ফোনে Download করে Extract করুন। Android-এর Files app-এ Extract option না থাকলে Play Store থেকে নির্ভরযোগ্য ZIP extractor ব্যবহার করুন।
4) Extract করা প্রজেক্টের সব ফাইল ও ফোল্ডার repository-তে upload করুন। গুরুত্বপূর্ণ: `.github/workflows/build-apk.yml` ফাইলটি যেন ওই path-এই থাকে।
5) GitHub repository > Actions tab খুলুন। “Build Amir Caller APK” workflow নির্বাচন করে “Run workflow” চাপুন। প্রথমবার Actions enable করতে বললে enable করুন।
6) Build শেষ হলে সবুজ successful run খুলুন।
7) নিচে Artifacts থেকে `Amir-Caller-debug-APK` ডাউনলোড করুন। ZIP extract করে `app-debug.apk` বের করুন।
8) APK-তে tap করে Android-এর নির্দেশনা অনুসারে “Install unknown apps” অনুমতি দিয়ে install করুন।

এই build GitHub-এর cloud computer-এ হবে, তাই নিজের ফোনে Android Studio লাগবে না। GitHub-এর UI/নীতিমালা সময়ের সঙ্গে বদলাতে পারে।

এই starter version-এ আছে:
- iPhone-inspired clean dialer UI, rounded buttons ও smooth tap animations
- Keypad, call/dial action, erase, add-contact shortcut
- ফোনের Contacts ও Call Log পড়া (permission দিলে)
- Contacts/Recents search
- Favorites view; starred contacts ও app-এর locally saved favorites
- Light/Dark mode, preference phone-এ save হয়

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি এখনো Android-এর পূর্ণ Default Dialer নয়। Incoming-call screen, call answer/end controls, SIM selection, Bluetooth/dual-SIM controls এবং Android Telecom default-dialer role আলাদা native implementation চায়।
- Android permission/ডিভাইসের নীতির কারণে Call Log permission সব ফোনে একইভাবে আচরণ নাও করতে পারে।
- GitHub-এ upload করার আগে চাইলে private repository ব্যবহার করতে পারেন; তবে private repository-তেও আপনার GitHub account প্রয়োজন।
- এটি unsigned debug APK। অন্যদের মধ্যে বিতরণ বা Play Store-এ প্রকাশের জন্য release signing, privacy policy, testing ও permission review দরকার।
