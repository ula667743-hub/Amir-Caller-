package com.amir.caller;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_PERMS = 41;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(246,247,249));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(246,247,249));
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(246,247,249));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PhoneBridge(), "AmirPhone");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        requestPermissionsIfNeeded();
    }

    private void requestPermissionsIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> p = new java.util.ArrayList<>();
            for (String permission : new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE}) {
                if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) p.add(permission);
            }
            if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (webView != null) webView.evaluateJavascript("if(window.refreshNativeData) refreshNativeData()", null);
    }

    public class PhoneBridge {
        @JavascriptInterface public String getContacts() {
            JSONArray out = new JSONArray();
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return out.toString();
            Cursor c = null;
            try {
                c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.STARRED},
                    null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
                if (c != null) while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("name", c.getString(0) == null ? "Unknown" : c.getString(0));
                    o.put("number", c.getString(1) == null ? "" : c.getString(1));
                    o.put("starred", c.getInt(2) == 1);
                    out.put(o);
                }
            } catch (Exception ignored) {} finally { if (c != null) c.close(); }
            return out.toString();
        }

        @JavascriptInterface public String getRecents() {
            JSONArray out = new JSONArray();
            if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return out.toString();
            Cursor c = null;
            try {
                c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE},
                    null, null, CallLog.Calls.DATE + " DESC");
                int count = 0;
                if (c != null) while (c.moveToNext() && count++ < 100) {
                    JSONObject o = new JSONObject();
                    o.put("name", c.getString(0) == null ? "" : c.getString(0));
                    o.put("number", c.getString(1) == null ? "" : c.getString(1));
                    o.put("date", c.getLong(2));
                    o.put("type", c.getInt(3));
                    out.put(o);
                }
            } catch (Exception ignored) {} finally { if (c != null) c.close(); }
            return out.toString();
        }

        @JavascriptInterface public void call(String number) {
            runOnUiThread(() -> {
                if (number == null || number.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a phone number", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent intent;
                    if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                        intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number.trim())));
                    else intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number.trim())));
                    startActivity(intent);
                } catch (Exception e) {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number.trim()))));
                }
            });
        }

        @JavascriptInterface public void addContact(String number) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                i.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                i.putExtra(ContactsContract.Intents.Insert.PHONE, number);
                startActivity(i);
            });
        }
    }
}
